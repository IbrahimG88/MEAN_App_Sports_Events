//Notes 20 is very useful regarding the ngform


Javascript form model created by angular: here we are telling to submit the javascript object ngForm angular created as attached to the # f reference variable and not the html form created