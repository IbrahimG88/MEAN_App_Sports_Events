import { NgModule } from '@angular/core';
import { AppComponent } from "./app.component";
import { BrowserModule } from "@angular/platform-browser";
import {  FormsModule, ReactiveFormsModule } from '@angular/forms';


import { eventComponent } from "./events/event.component";

@NgModule({
    declarations: [AppComponent, eventComponent],
    imports: [
        BrowserModule, 
        FormsModule,
        ReactiveFormsModule
    ],
    bootstrap: [AppComponent]
})
export class AppModule{

}
